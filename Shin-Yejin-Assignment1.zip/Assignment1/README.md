Yejin Shin
CSE 310
111850347

The only library used for this assignment was python sockets.

How to run my programs:

1. The port number {1124} was used for both programs.
   For webserver.py

- run webserver.py in your computer (cmd or terminal)
- put http://localhost:1124/HelloWorld.html
- HelloWorld.html is in the same directory as these files

For proxyserver.py

- run proxyserver.py in your computer (cmd or terminal)
- put http://localhost:1124/www.example.com
- I used example.com for practice since google.com does not work due to its enormous size.
- You can try with other websites such as stonybrook.edu or uber.com
- If this error [OSError: [Errno 48] Address already in use] comes up, wait few mintues and try with the same command.
